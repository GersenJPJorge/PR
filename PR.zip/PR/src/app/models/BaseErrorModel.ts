export class BaseErrorModel {
  constructor(public status?: number, public message?: string) {
  }
}
