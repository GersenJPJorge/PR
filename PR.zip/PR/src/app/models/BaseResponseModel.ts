export class BaseResponseModel {
         constructor(public code?: number, public message?: string) {
         }
}
